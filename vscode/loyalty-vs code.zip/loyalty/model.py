import pickle
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import RobustScaler, OneHotEncoder, LabelEncoder
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from sklearn.model_selection import train_test_split

try:
    df = pd.read_csv(r'C:\Users\Benny\Desktop\loyalty\Electronic - Electronic.csv.csv')
    print("Data loaded successfully")
except Exception as e:
    print(f"Error loading data: {e}")
    # Exit the script if data cannot be loaded
    exit()
    
# Data preprocessing steps
df['Avg Spending per Purchase'] = df['Total Spent'] / df['Items Purchased']
df['Discounted Revenue'] = df['Revenue'] * (1 - df['Discount (%)'] / 100)
bins = [0, 18, 30, 50, 65, 100]
labels = ['Under 18', '18-30', '31-50', '51-65', '65+']
df['Age Group'] = pd.cut(df['Age'], bins=bins, labels=labels)
loyalty_bins = [0, 10, 20, df['Loyalty Score'].max()]
loyalty_labels = ['Low', 'Medium', 'High']
df['Loyalty Category'] = pd.cut(df['Loyalty Score'], bins=loyalty_bins, labels=loyalty_labels, right=True, include_lowest=True)


# Drop unnecessary columns
columns_to_drop = ['Total Spent', 'Items Purchased', 'Revenue', 'Discount (%)', 'Age','Loyalty Score']
df.drop(columns=columns_to_drop, inplace=True)

# Define features and target
target_column ='Loyalty Category'
selected_features = [
    'Satisfaction Score', 'Avg Spending per Purchase', 'Discounted Revenue',
    'Region', 'Payment Method', 'Preferred Visit Time', 'Gender', 'Age Group'
]

X = df[selected_features]
y = df[target_column]

# Define preprocessing
categorical_columns = ['Region', 'Payment Method', 'Preferred Visit Time', 'Gender', 'Age Group']
numerical_columns = ['Satisfaction Score', 'Avg Spending per Purchase', 'Discounted Revenue']

preprocessor = ColumnTransformer(
    transformers=[
        ('num', RobustScaler(), numerical_columns),
        ('cat', OneHotEncoder(drop='first'), categorical_columns)
    ]
)

# Create pipeline
pipeline = Pipeline(steps=[
    ('preprocessor', preprocessor),
    ('classifier', RandomForestClassifier(random_state=42))
])

# Train/test split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train model
pipeline.fit(X_train, y_train)

# Save pipeline
with open('model_pipeline.pkl', 'wb') as file:
    pickle.dump(pipeline, file)
